`timescale 1ns/1ps
module tb_roi_accuracy;
 reg clk=0;always #5 clk=~clk;
 reg rst=0,sof=0,de=0,valid=1;
 reg [5:0] disparity=1;
 reg [8:0] scale=256;
 wire [15:0] cm;wire dv;wire [5:0] dom;
 depth_roi dut(clk,rst,sof,de,valid,11'd200,11'd240,11'd800,11'd480,disparity,scale,cm,dv,dom);
 integer i,k,expected,lower,upper_count;real true_d;
 task finish_frame;
 begin @(negedge clk);de=0;sof=1;@(negedge clk);sof=0;repeat(200)@(negedge clk);end
 endtask
 initial begin
  repeat(4)@(negedge clk);rst=1;
  for(k=0;k<6;k=k+1)begin
   case(k)0:expected=50;1:expected=75;2:expected=100;3:expected=150;4:expected=200;5:expected=300;endcase
   true_d=346.0*32.0/(10.0*expected);lower=$rtoi(true_d);
   upper_count=$rtoi((true_d-lower)*1600.0+0.5);
   for(i=0;i<1600;i=i+1)begin @(negedge clk);de=1;disparity=i<upper_count?lower+1:lower;end
   finish_frame;
   if(!dv || cm<expected-1 || cm>expected+1)$fatal(1,"Distance arithmetic at %0d cm: got=%0d valid=%b",expected,cm,dv);
  end
  for(i=0;i<1600;i=i+1)begin @(negedge clk);de=1;disparity=1+i%63;end
  finish_frame;if(dv)$fatal(1,"Ambiguous mixed-depth ROI accepted");
  finish_frame;if(dv)$fatal(1,"Empty ROI retained distance");
  $display("PASS ROI arithmetic 0.5/0.75/1/1.5/2/3m, <=1cm numerical error, mixed-depth rejection and stale clearing");$finish;
 end
endmodule
