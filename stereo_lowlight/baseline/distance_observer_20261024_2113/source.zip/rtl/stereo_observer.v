`timescale 1ns/1ps
// Read-only diagnostic tap: live 100x60 RGB565 thumbnail of both LCD inputs.
// Independent read clock, registered address/data; no back-pressure on video.
module stereo_observer(
 input wire pixel_clk,read_clk,rst_n,de,
 input wire [10:0] x,y,
 input wire [15:0] rgb,
 output wire [31:0] sample
);
 (* ram_style="block" *) reg [15:0] image[0:5999];
 wire [12:0] wa=(y>>3)*13'd100+(x>>3);
 always @(posedge pixel_clk)
  if(de&&x<800&&y<480&&x[2:0]==0&&y[2:0]==0)image[wa]<=rgb;
 reg [12:0] ra,addr;
 reg [15:0] pixel;
 always @(posedge read_clk)pixel<=image[ra];
 always @(posedge read_clk or negedge rst_n)
  if(!rst_n)begin ra<=0;addr<=0;end
  else begin ra<=ra==5999?13'd0:ra+1'b1;addr<=ra;end
 assign sample={3'b101,addr,pixel};
endmodule
