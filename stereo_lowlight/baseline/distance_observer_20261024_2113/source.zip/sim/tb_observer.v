`timescale 1ns/1ps
module tb_observer;
 reg pc=0,rc=0;always #20 pc=~pc;always #10 rc=~rc;
 reg rst=0,de=0;reg [10:0] x=0,y=0;reg [15:0] rgb=0;
 wire [31:0] sample;
 stereo_observer dut(pc,rc,rst,de,x,y,rgb,sample);
 integer xx,yy,n=0,seen=0,addr;
 function [15:0] expected;
 input integer a;
 begin expected=(a*37)^16'h9c12;end
 endfunction
 initial begin
  repeat(4)@(negedge pc);rst=1;
  for(yy=0;yy<60;yy=yy+1)for(xx=0;xx<100;xx=xx+1)begin
   @(negedge pc);de=1;x=xx*8;y=yy*8;rgb=expected(yy*100+xx);
  end
  @(negedge pc);de=0;
  for(n=0;n<6200;n=n+1)begin
   @(negedge rc);addr=sample[28:16];
   if(sample[31:29]!==3'b101||addr>=6000||sample[15:0]!==expected(addr))
    $fatal(1,"Observer address/data mismatch at %0d got %h",addr,sample);
   seen=seen+1;
  end
  $display("PASS diagnostic thumbnail: all 6000 pixels, independent clocks, registered address/data");$finish;
 end
endmodule
