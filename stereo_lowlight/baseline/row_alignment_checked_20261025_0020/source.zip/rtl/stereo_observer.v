`timescale 1ns/1ps
// Read-only 100x60 luminance tap, programmable 8x8 sample phase.
// Independent read clock, registered address/data; no back-pressure on video.
module stereo_observer(
 input wire pixel_clk,read_clk,rst_n,de,
 input wire [10:0] x,y,
 input wire [15:0] rgb,
 input wire [5:0] phase,
 output wire [31:0] sample
);
 (* ram_style="block" *) reg [7:0] image[0:5999];
 wire [7:0] r={rgb[15:11],rgb[15:13]},g={rgb[10:5],rgb[10:9]},b={rgb[4:0],rgb[4:2]};
 wire [15:0] sum=77*r+150*g+29*b;
 wire [12:0] wa=(y>>3)*13'd100+(x>>3);
 always @(posedge pixel_clk)
  if(de&&x<800&&y<480&&x[2:0]==phase[2:0]&&y[2:0]==phase[5:3])image[wa]<=sum[15:8];
 reg [12:0] ra,addr;
 reg [7:0] pixel;
 (* ASYNC_REG="TRUE" *) reg [5:0] ps1,ps2;
 always @(posedge read_clk)pixel<=image[ra];
 always @(posedge read_clk or negedge rst_n)
  if(!rst_n)begin ra<=0;addr<=0;ps1<=0;ps2<=0;end
  else begin ra<=ra==5999?13'd0:ra+1'b1;addr<=ra;ps1<=phase;ps2<=ps1;end
 assign sample={3'b110,addr,ps2,2'b01,pixel};
endmodule
